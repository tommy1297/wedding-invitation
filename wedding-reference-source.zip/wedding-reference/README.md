# Wedding Invitation — reference-inspired

Original HTML/CSS/JS implementation inspired by an elegant single-page invitation layout. Not the source code or copyrighted assets of the reference site.

## Quick start from Android
1. Unzip the project on Android using Files.
2. Open github.com and create a PUBLIC repository named `wedding-invitation`.
3. Click **Add file > Upload files** and upload `index.html`, plus the `css`, `js`, `supabase`, and `assets` folders while preserving their paths. If your Android file picker does not support folders, use github.dev (press `.` on repository) or create folders/files individually in GitHub.
4. In repository **Settings > Pages**, choose **Deploy from a branch**, `main`, `/ (root)` and Save.
5. Wait for `https://USERNAME.github.io/wedding-invitation/` to appear.

## Connect Supabase
1. Create a free project at https://supabase.com/dashboard.
2. Go to SQL Editor and run `supabase/setup.sql`.
3. Copy **Project URL** and **publishable key** (legacy anon key also works) from Supabase project API settings.
4. Edit `js/config.js` in GitHub, replacing the two `PASTE_...` values. Commit changes.
5. Refresh the site, submit a test wish, check that it appears.
6. NEVER paste a secret or service_role key into frontend code. This project uses Row Level Security. Public forms can attract spam; add CAPTCHA/rate limiting or moderation before wide release.

## Customize
- In `index.html`, change Alya/Bima, parents, venue, date, Google Maps, and bank details.
- In `js/config.js`, change date and Google Calendar UTC times (ensure correct timezone).
- Replace sample image placeholders by uploading `assets/images/bride.jpg`, `groom.jpg`, and `gallery-1.jpg` through `gallery-4.jpg`.
- Add licensed music at `assets/music/wedding.mp3`. Music requires user click to start.
- URL personalization: `https://YOURDOMAIN.site/?to=Keluarga%20Andi`.

## Custom .site domain
Buy a `.site` domain from a registrar. In GitHub Settings > Pages > Custom domain, add the domain. Configure DNS according to GitHub's current Pages documentation; for `www`, a CNAME usually points to `USERNAME.github.io`. Enable HTTPS after validation.

## Notes
- RSVP and wishes are saved in the same public table, including attendance. Public visitors can see attendance; for privacy, separate RSVP from public wishes before production.
- Photos in the starter are external placeholders from Unsplash and should be replaced with your own.
- The layout is an original interpretation, not a pixel-perfect copy of the referenced website.
